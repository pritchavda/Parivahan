import * as chai from 'chai';

const expect = chai.expect;

// TODO: move relevant tests from the `geofire` package to `geofire-common`.
describe('Dummy test to ensure the run succeeds:', () => {
  it("hello world", () => {
    expect(true).to.be.true;
  });
});
